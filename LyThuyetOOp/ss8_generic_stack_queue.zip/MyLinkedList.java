package ss8_generic_stack_queue;

/// Hãy tự tạo MyLinkedList với kiểu generic
public class MyLinkedList<E> {
    // Copy lại MyLinkedList và sửa lại theo kiểu generic
}

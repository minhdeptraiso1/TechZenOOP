package ss8_generic_stack_queue;

public class Main {
    public static void main(String[] args) {
//        MyLinkedList<Integer> integerMyLinkedList = new MyLinkedList<>();
//        integerMyLinkedList.addLast(10);
//
//        MyLinkedList<String> stringMyLinkedList = new MyLinkedList<>();
//        stringMyLinkedList.addLast("hello");
    }
}
